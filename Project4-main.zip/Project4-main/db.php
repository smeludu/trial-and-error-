<?php
$server="localhost";
$username="username";
$password="user";
$database="gym";
$port = 8080;

$conn=mysqli_connect($server,$username,$password,$database, $port);

?>